const mongoose = require('mongoose');

const saleSchema = new mongoose.Schema({
  phoneId: { type: mongoose.Schema.Types.ObjectId, ref: 'Phone' },
  model: String,
  priceBuy: Number,
  priceSell: Number,
  dateSold: { type: Date, default: Date.now },
  quantity: { type: Number, default: 1 },
  profit: Number
});

module.exports = mongoose.models.Sale || mongoose.model('Sale', saleSchema);
