const mongoose = require('mongoose');

const historySchema = new mongoose.Schema({
  model: String,
  price: Number,
  image: String,
  dateAdded: { type: Date, default: Date.now }
});

module.exports = mongoose.models.History || mongoose.model('History', historySchema);
