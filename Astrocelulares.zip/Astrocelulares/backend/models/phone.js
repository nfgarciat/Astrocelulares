const mongoose = require('mongoose');

const phoneSchema = new mongoose.Schema({
  model: String,
  price: Number,
  historia: String,
  caracteristicas: String,
  image: String,
  stock: Number,
  dateAdded: { type: Date, default: Date.now }
});

module.exports = mongoose.models.Phone || mongoose.model('Phone', phoneSchema);
