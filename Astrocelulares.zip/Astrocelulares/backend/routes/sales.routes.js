const express = require('express');
const router = express.Router();
const Sale = require('../models/sale');

router.get('/', async (req, res) => {
  // Puedes recibir ?start=YYYY-MM-DD&end=YYYY-MM-DD para filtrar fechas
  const { start, end } = req.query;
  const filter = {};
  if (start && end) {
    filter.dateSold = {
      $gte: new Date(start),
      $lte: new Date(end)
    };
  }
  const sales = await Sale.find(filter).sort({ dateSold: -1 });
  res.json(sales);
});

module.exports = router;
