const express = require('express');
const router = express.Router();
const Transaction = require('../models/Transaction');

// Obtener todas las transacciones
router.get('/', async (req, res) => {
  try {
    const transactions = await Transaction.find().sort({ fecha: -1 });
    res.json(transactions);
  } catch (err) {
    res.status(500).json({ error: 'Error al obtener transacciones' });
  }
});

// Ruta para calcular el balance (ingresos, egresos, utilidad)
router.get('/financial-balance', async (req, res) => {
  console.log('Ruta /financial-balance llamada');
  
  try {
    const transactions = await Transaction.find();

    let ingresos = 0;
    let egresos = 0;
    let utilidad = 0;

    for (const t of transactions) {
      if (t.tipo === 'ingreso') ingresos += t.monto;
      if (t.tipo === 'egreso') egresos += t.monto;
      if (t.categoria === 'utilidad') utilidad += t.monto;
    }

    res.json({ ingresos, egresos, utilidad });
  } catch (err) {
    res.status(500).json({ error: 'Error al calcular balance' });
  }
});

// Estadísticas: ganancias mensuales
router.get('/stats/profit-by-month', async (req, res) => {
  try {
    const stats = await Transaction.aggregate([
      { $match: { categoria: 'utilidad' } },  // solo ganancias
      {
        $group: {
          _id: { month: { $month: "$fecha" }, year: { $year: "$fecha" } },
          totalProfit: { $sum: "$monto" }
        }
      },
      { $sort: { "_id.year": 1, "_id.month": 1 } }
    ]);
    res.json(stats);
  } catch (err) {
    console.error('Error calculando ganancias mensuales:', err);
    res.status(500).json({ error: 'Error calculando ganancias mensuales' });
  }
});

module.exports = router;
