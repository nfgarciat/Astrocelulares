const express = require('express');
const router = express.Router();
const Transaction = require('../models/transaction');

router.get('/', async (req, res) => {
  const ingresos = await Transaction.aggregate([
    { $match: { tipo: 'ingreso' } },
    { $group: { _id: null, total: { $sum: '$monto' } } }
  ]);

  const egresos = await Transaction.aggregate([
    { $match: { tipo: 'egreso' } },
    { $group: { _id: null, total: { $sum: '$monto' } } }
  ]);

  const ingresoTotal = ingresos[0]?.total || 0;
  const egresoTotal = egresos[0]?.total || 0;

  res.json({
    ingresos: ingresoTotal,
    egresos: egresoTotal,
    utilidad: ingresoTotal - egresoTotal
  });
});

module.exports = router;
