import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip,
  ResponsiveContainer, CartesianGrid
} from 'recharts';

export default function AstroCelularesApp() {
  const [selectedTab, setSelectedTab] = useState('stock');
  const [phones, setPhones] = useState([]);
  const [history, setHistory] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [balance, setBalance] = useState({ ingresos: 0, egresos: 0, utilidad: 0 });
  const [transactionForm, setTransactionForm] = useState({ tipo: 'ingreso', concepto: '', monto: '', categoria: '' });
  const [ventaModal, setVentaModal] = useState({ visible: false, phone: null, monto: '' });
  const [sales, setSales] = useState([]);
  const [filterDates, setFilterDates] = useState({ start: '', end: '' });

  const fileInputRef = useRef(null);

  const [formData, setFormData] = useState({
    model: '',
    price: '',
    historia: '',
    caracteristicas: '',
    image: 'https://i.imgur.com/placeholder.png'
  });

  const [chartType, setChartType] = useState('ventas');
  const [chartData, setChartData] = useState([]);

  useEffect(() => {
    fetchPhones();
    fetchHistory();
    fetchTransactions();
    fetchBalance();
  }, []);

  useEffect(() => {
    fetchSales(filterDates.start, filterDates.end);
  }, [filterDates]);

  useEffect(() => {
    const fetchChartData = async () => {
      try {
        const endpoint =
          chartType === 'ventas'
            ? 'http://localhost:4000/stats/sales-by-model'
            : 'http://localhost:4000/stats/profit-by-month'; // Este debe ser exactamente así


        const res = await axios.get(endpoint);
        console.log('Datos gráfica:', res.data);


        if (chartType === 'ingresos') {
          const meses = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
          setChartData(
            res.data.map(item => ({
              ...item,
              monthYear: `${meses[item._id.month - 1]} ${item._id.year}`,
              totalProfit: item.totalProfit
            }))
          );
        } else {
          setChartData(res.data);
        }
      } catch (err) {
        console.error('Error obteniendo datos de gráfica:', err);
      }
    };

    fetchChartData();
  }, [chartType]);

  const fetchPhones = async () => {
    try {
      const res = await axios.get('http://localhost:4000/phones');
      setPhones(res.data);
    } catch (err) {
      console.error('Error cargando celulares:', err);
    }
  };

  const fetchHistory = async () => {
    try {
      const res = await axios.get('http://localhost:4000/history');
      setHistory(res.data);
    } catch (err) {
      console.error('Error cargando historial:', err);
    }
  };

  const fetchTransactions = async () => {
    try {
      const res = await axios.get('http://localhost:4000/transactions');
      setTransactions(res.data);
    } catch (err) {
      console.error('Error cargando transacciones:', err);
    }
  };

  const fetchBalance = async () => {
    try {
      const res = await axios.get('http://localhost:4000/financial-balance');
      setBalance(res.data);
    } catch (err) {
      console.error('Error cargando balance:', err);
    }
  };

  const handleTransactionChange = (e) => {
    const { name, value } = e.target;
    setTransactionForm({ ...transactionForm, [name]: value });
  };

  const handleTransactionSubmit = async () => {
    try {
      await axios.post('http://localhost:4000/transactions', {
        type: transactionForm.tipo,
        concepto: transactionForm.concepto,
        monto: parseFloat(transactionForm.monto),
        categoria: transactionForm.categoria
      });
      setTransactionForm({ tipo: 'ingreso', concepto: '', monto: '', categoria: '' });
      fetchTransactions();
      fetchBalance();
    } catch (err) {
      console.error('Error creando transacción:', err);
    }
  };

  const handleVentaSubmit = async () => {
    if (!ventaModal.monto || isNaN(parseFloat(ventaModal.monto))) {
      alert("Por favor, ingresa un precio de venta válido.");
      return;
    }

    try {
      await axios.post(`http://localhost:4000/phones/sell/${ventaModal.phone._id}`, {
        monto: parseFloat(ventaModal.monto)
      });

      // Remueve el teléfono del estado si ya no tiene stock
      setPhones(prev =>
        prev
          .map(p => (p._id === ventaModal.phone._id ? { ...p, stock: p.stock - 1 } : p))
          .filter(p => p.stock > 0)
      );

      setVentaModal({ visible: false, phone: null, monto: '' });
      fetchTransactions();
      fetchBalance();
    } catch (err) {
      console.error('Error al vender celular:', err);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData({ ...formData, image: reader.result });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRegister = async () => {
    if (!formData.model || !formData.price) return;
    try {
      await axios.post('http://localhost:4000/phones', {
        ...formData,
        price: parseInt(formData.price),
        stock: 1
      });
      setFormData({ model: '', price: '', historia: '', caracteristicas: '', image: 'https://i.imgur.com/placeholder.png' });
      fetchPhones();
      fetchHistory();
      setSelectedTab('stock');
    } catch (err) {
      console.error('Error registrando celular:', err);
    }
  };

  const fetchSales = async (start = '', end = '') => {
    try {
      let url = 'http://localhost:4000/sales';
      if (start && end) {
        url += `?start=${start}&end=${end}`;
      }
      const res = await axios.get(url);
      setSales(res.data);
    } catch (err) {
      console.error('Error cargando ventas:', err);
    }
  };

  return (
    <div style={{ display: 'flex', height: '100vh', width: '100vw', overflow: 'hidden', fontFamily: 'sans-serif' }}>
      <div style={{ width: '240px', background: 'white', borderRight: '1px solid #ddd', padding: '24px' }}>
        <h2 style={{ color: '#7c3aed', marginBottom: '32px' }}>AstroCelulares</h2>
        <nav style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <button onClick={() => setSelectedTab('stock')}>📦 Stock</button>
          <button onClick={() => setSelectedTab('registro')}>➕ Registrar</button>
          <button onClick={() => setSelectedTab('grafica')}>📊 Gráficas</button>
          <button onClick={() => setSelectedTab('historial')}>📅 Historial</button>
          <button onClick={() => setSelectedTab('finanzas')}>💰 Finanzas</button>
          <button onClick={() => setSelectedTab('ventas')}>🛒 Ventas</button>
        </nav>
      </div>

      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', backgroundColor: '#1f1f1f', color: 'white' }}>
        <div style={{ background: '#7c3aed', padding: '16px', display: 'flex', justifyContent: 'space-between' }}>
          <span>{selectedTab.toUpperCase()}</span>
          <div>👤 ⚙️</div>
        </div>

        <div style={{ padding: '24px', overflowY: 'auto', flex: 1 }}>
          {selectedTab === 'stock' && (
            <div style={{ display: 'grid', gap: '16px', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))' }}>
              {phones.filter(phone => phone.stock > 0).map((phone, idx) => (
                <div key={idx} style={{ backgroundColor: 'white', color: 'black', padding: '12px', borderRadius: '8px' }}>
<img src={phone.image} alt={phone.model} style={{ width: '100%', height: '140px', objectFit: 'contain', backgroundColor: '#f0f0f0' }} />
                  <strong>{phone.model}</strong>
                  <p style={{ fontSize: '14px', marginTop: '4px' }}>{phone.caracteristicas}</p>
                  <p>📦 {phone.stock} — 💰 ${phone.price}</p>
                  <button onClick={() => setVentaModal({ visible: true, phone, monto: '' })} style={{ marginTop: '8px', backgroundColor: '#7c3aed', color: 'white', padding: '4px 8px', borderRadius: '4px' }}>Vendido</button>
                </div>
              ))}
            </div>
          )}

          {selectedTab === 'registro' && (
            <div style={{ display: 'flex', gap: '32px' }}>
              <div style={{ flex: 1 }}>
                <div style={{ backgroundColor: 'white', borderRadius: '8px', padding: '12px', textAlign: 'center' }}>
                  <img src={formData.image} alt="preview" style={{ width: '100%', maxHeight: '300px', objectFit: 'contain' }} />
                  <input type="file" ref={fileInputRef} style={{ display: 'none' }} onChange={handleImageUpload} />
                  <button onClick={() => fileInputRef.current.click()} style={{ marginTop: '12px', backgroundColor: '#7c3aed', color: 'white', padding: '6px 12px', borderRadius: '4px' }}>Subir Imagen</button>
                </div>
              </div>
              <div style={{ flex: 1 }}>
                <h3>Registrar Celular</h3>
                <input name="model" placeholder="Modelo" value={formData.model} onChange={handleInputChange} style={{ display: 'block', marginBottom: '8px', width: '100%' }} />
                <input name="price" placeholder="Precio" value={formData.price} onChange={handleInputChange} style={{ display: 'block', marginBottom: '8px', width: '100%' }} />
                <input name="historia" placeholder="Historia" value={formData.historia} onChange={handleInputChange} style={{ display: 'block', marginBottom: '8px', width: '100%' }} />
                <input name="caracteristicas" placeholder="Características" value={formData.caracteristicas} onChange={handleInputChange} style={{ display: 'block', marginBottom: '8px', width: '100%' }} />
                <button onClick={handleRegister} style={{ backgroundColor: '#7c3aed', color: 'white', padding: '10px', width: '100%', borderRadius: '4px' }}>Registrar</button>
              </div>
            </div>
          )}

          {selectedTab === 'grafica' && (
            <div>
              <h3>Gráficas</h3>
              <select onChange={(e) => setChartType(e.target.value)} value={chartType} style={{ marginBottom: '16px' }}>
                <option value="ventas">📈 Ventas por modelo</option>
                <option value="ingresos">💸 Ingresos mensuales</option>
              </select>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey={chartType === 'ventas' ? '_id' : 'monthYear'} />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey={chartType === 'ventas' ? 'total' : 'totalProfit'} fill="#7c3aed" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}

          {selectedTab === 'historial' && (
            <div>
              <h3>Historial</h3>
              {history.map((item, idx) => (
                <div key={idx} style={{ backgroundColor: 'white', color: 'black', marginBottom: '8px', padding: '12px', borderRadius: '8px' }}>
                  <strong>{item.model}</strong>
                  <p>💰 ${item.price} | 📅 {new Date(item.dateAdded).toLocaleDateString()}</p>
                  <p><strong>Características:</strong> {item.caracteristicas || 'Sin especificar'}</p>
                  <p><strong>Historia:</strong> {item.historia || 'Sin historia registrada'}</p>
                </div>
              ))}
            </div>
          )}

          {selectedTab === 'ventas' && (
            <div style={{ color: 'white' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', color: 'white' }}>
                <thead>
                  <tr style={{ borderBottom: '1px solid gray' }}>
                    <th style={{ padding: '8px' }}>Modelo</th>
                    <th style={{ padding: '8px' }}>Fecha Venta</th>
                    <th style={{ padding: '8px' }}>Precio Compra</th>
                    <th style={{ padding: '8px' }}>Precio Venta</th>
                    <th style={{ padding: '8px' }}>Ganancia</th>
                    <th style={{ padding: '8px' }}>Cantidad</th>
                  </tr>
                </thead>
                <tbody>
                  {sales.length === 0 ? (
                    <tr>
                      <td colSpan="6" style={{ textAlign: 'center', padding: '12px' }}>
                        No hay ventas para mostrar.
                      </td>
                    </tr>
                  ) : (
                    sales.map((sale, idx) => (
                      <tr key={idx} style={{ borderBottom: '1px solid #444' }}>
                        <td style={{ padding: '8px' }}>{sale.model}</td>
                        <td style={{ padding: '8px' }}>{new Date(sale.dateSold).toLocaleDateString()}</td>
                        <td style={{ padding: '8px' }}>${sale.priceBuy}</td>
                        <td style={{ padding: '8px' }}>${sale.priceSell}</td>
                        <td style={{ padding: '8px' }}>${sale.profit}</td>
                        <td style={{ padding: '8px' }}>{sale.quantity}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}

          {selectedTab === 'finanzas' && (
            <div>
              <h3>Finanzas</h3>
              <p>💸 Ingresos: <strong style={{ color: 'lightgreen' }}>${balance.ingresos || 0}</strong></p>
              <p>📤 Egresos: <strong style={{ color: 'tomato' }}>${balance.egresos || 0}</strong></p>
              <p>📊 Utilidad: <strong style={{ color: 'gold' }}>${balance.utilidad || 0}</strong></p>

              <h4 style={{ marginTop: '32px' }}>📄 Historial de transacciones</h4>
              <div style={{ backgroundColor: '#2c2c2c', padding: '16px', borderRadius: '8px' }}>
                {transactions.length === 0 ? (
                  <p style={{ color: 'gray' }}>No hay transacciones registradas.</p>
                ) : (
                  <ul style={{ listStyle: 'none', padding: 0 }}>
                    {transactions
                      .slice()
                      .reverse()
                      .map((t, idx) => (
                        <li key={idx} style={{ marginBottom: '8px', padding: '8px', borderBottom: '1px solid #444' }}>
                          <strong style={{ color: t.tipo === 'ingreso' ? 'lightgreen' : 'tomato' }}>
                            {t.tipo.toUpperCase()}
                          </strong>{' '}
                          — {t.concepto} — 💰 ${t.monto} — <em>{t.categoria}</em>
                        </li>
                      ))}
                  </ul>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* MODAL VENTA */}
      {ventaModal.visible && (
        <div
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            width: '100vw',
            height: '100vh',
            backgroundColor: 'rgba(0,0,0,0.6)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 9999
          }}
        >
          <div style={{ backgroundColor: 'white', color: 'black', padding: '24px', borderRadius: '12px', minWidth: '300px' }}>
            <h3>¿En cuánto se vendió {ventaModal.phone.model}?</h3>
            <input
              type="number"
              placeholder="Precio de venta"
              value={ventaModal.monto}
              onChange={(e) => setVentaModal({ ...ventaModal, monto: e.target.value })}
              style={{ width: '100%', marginTop: '12px', padding: '8px' }}
            />
            <div style={{ marginTop: '16px', display: 'flex', justifyContent: 'space-between' }}>
              <button
                onClick={() => setVentaModal({ visible: false, phone: null, monto: '' })}
                style={{ backgroundColor: '#ccc', padding: '8px 16px', borderRadius: '6px' }}
              >
                Cancelar
              </button>
              <button
                onClick={handleVentaSubmit}
                style={{ backgroundColor: '#7c3aed', color: 'white', padding: '8px 16px', borderRadius: '6px' }}
              >
                Confirmar venta
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
