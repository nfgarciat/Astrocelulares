const mongoose = require('mongoose');

const transactionSchema = new mongoose.Schema({
  tipo: { type: String, enum: ['ingreso', 'egreso'], required: true },
  concepto: { type: String, required: true },
  monto: { type: Number, required: true },
  categoria: String,
  fecha: { type: Date, default: Date.now }
});

module.exports = mongoose.models.Transaction || mongoose.model('Transaction', transactionSchema);
