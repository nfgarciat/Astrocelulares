const express = require('express');
const router = express.Router();

const Phone = require('../models/Phone');
const Transaction = require('../models/Transaction');

// Obtener todos los celulares
router.get('/', async (req, res) => {
  const phones = await Phone.find().sort({ dateAdded: -1 });
  res.send(phones);
});

// Registrar un nuevo celular
router.post('/', async (req, res) => {
  try {
    const phone = new Phone(req.body);
    await phone.save();
    res.status(201).send(phone);
  } catch (err) {
    res.status(500).send('Error al guardar el celular');
  }
});

// Historial (todos los celulares)
router.get('/history', async (req, res) => {
  const history = await Phone.find().sort({ dateAdded: -1 });
  res.send(history);
});

// Registrar venta de un celular
router.post('/sell/:id', async (req, res) => {
  const { id } = req.params;
  const { monto } = req.body;

  try {
    const phone = await Phone.findById(id);
    if (!phone || phone.stock <= 0) return res.status(404).send('Celular no disponible');

    // Reducir stock
    phone.stock -= 1;
    await phone.save();

    // Registrar como transacción de ingreso
    const venta = new Transaction({
      typo: 'ingreso',
      concepto: `Venta ${phone.model}`,
      monto: parseFloat(monto),
      categoria: 'venta'
    });

    await venta.save();

    res.send({ success: true });
  } catch (err) {
    console.error('Error al vender celular:', err);
    res.status(500).send('Error al procesar venta');
  }
});

// Estadísticas: ventas por modelo
router.get('/stats/sales-by-model', async (req, res) => {
  const stats = await Phone.aggregate([
    { $group: { _id: "$model", total: { $sum: 1 }, revenue: { $sum: "$price" } } },
    { $sort: { total: -1 } }
  ]);
  res.json(stats);
});

// Estadísticas: ingresos por mes
router.get('/stats/sales-by-month', async (req, res) => {
  const stats = await Phone.aggregate([
    {
      $group: {
        _id: { $month: "$dateAdded" },
        total: { $sum: 1 },
        revenue: { $sum: "$price" }
      }
    },
    { $sort: { _id: 1 } }
  ]);
  res.json(stats);
});

module.exports = router;
