const express = require('express');
const router = express.Router();
const Transaction = require('../models/Transaction');

// Crear una nueva transacción
router.post('/', async (req, res) => {
  try {
    const nueva = new Transaction({
      tipo: req.body.tipo,
      concepto: req.body.concepto,
      monto: parseFloat(req.body.monto),
      categoria: req.body.categoria,
      fecha: new Date()
    });
    await nueva.save();
    res.status(201).send(nueva);
  } catch (err) {
    console.error('Error al crear transacción:', err);
    res.status(400).send({ error: 'Error creando transacción', detalles: err });
  }
});

// Obtener todas las transacciones
router.get('/', async (req, res) => {
  const transacciones = await Transaction.find().sort({ fecha: -1 });
  res.send(transacciones);
});

// Obtener balance general (ingresos, egresos y utilidad)
router.get('/balance', async (req, res) => {
  try {
    const ingresos = await Transaction.aggregate([
      { $match: { tipo: 'ingreso' } },
      { $group: { _id: null, total: { $sum: '$monto' } } }
    ]);

    const egresos = await Transaction.aggregate([
      { $match: { tipo: 'egreso' } },
      { $group: { _id: null, total: { $sum: '$monto' } } }
    ]);

    res.send({
      ingresos: ingresos[0]?.total || 0,
      egresos: egresos[0]?.total || 0,
      utilidad: (ingresos[0]?.total || 0) - (egresos[0]?.total || 0)
    });
  } catch (err) {
    console.error('Error al calcular balance:', err);
    res.status(500).send('Error al obtener el balance');
  }
});

module.exports = router;
