const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const phonesRoutes = require('./routes/phones.routes');
const transactionsRoutes = require('./routes/transactions.routes');

const app = express();
app.use(cors());
app.use(express.json({ limit: '10mb' }));

// Conexión a MongoDB
mongoose.connect('mongodb+srv://andruquiroz27:andruz112@astrocelulares.srhro4h.mongodb.net/Astrocelulares?retryWrites=true&w=majority')
  .then(() => console.log('✅ Conectado a MongoDB'))
  .catch(err => console.error('❌ Error al conectar a MongoDB', err));

// Rutas
app.use('/phones', phonesRoutes);
app.use('/transactions', transactionsRoutes);
app.use('/balance', transactionsRoutes); // reutilizamos las rutas para /balance

// Modelo directo para estadísticas
const Phone = require('./models/Phone');

// Ruta para ventas por modelo
app.get('/stats/sales-by-model', async (req, res) => {
  const stats = await Phone.aggregate([
    { $group: { _id: "$model", total: { $sum: 1 }, revenue: { $sum: "$price" } } },
    { $sort: { total: -1 } }
  ]);
  res.json(stats);
});

// Ruta para ingresos mensuales
app.get('/stats/sales-by-month', async (req, res) => {
  const stats = await Phone.aggregate([
    {
      $group: {
        _id: { $month: "$dateAdded" },
        total: { $sum: 1 },
        revenue: { $sum: "$price" }
      }
    },
    { $sort: { _id: 1 } }
  ]);
  res.json(stats);
});

// Historial (misma colección de teléfonos)
app.get('/history', async (req, res) => {
  const history = await Phone.find().sort({ dateAdded: -1 });
  res.send(history);
});

// Iniciar el servidor
app.listen(4000, () => {
  console.log('🚀 API escuchando en http://localhost:4000');
});
