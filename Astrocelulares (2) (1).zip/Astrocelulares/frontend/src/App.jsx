import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip,
  ResponsiveContainer, CartesianGrid
} from 'recharts';

export default function AstroCelularesApp() {
  const [selectedTab, setSelectedTab] = useState('stock');
  const [phones, setPhones] = useState([]);
  const [history, setHistory] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [balance, setBalance] = useState({ ingresos: 0, egresos: 0, utilidad: 0 });
  const [transactionForm, setTransactionForm] = useState({ tipo: 'ingreso', concepto: '', monto: '', categoria: '' });
  const [ventaModal, setVentaModal] = useState({ visible: false, phone: null, monto: '' });

  const fileInputRef = useRef(null);

  const [formData, setFormData] = useState({
    model: '',
    price: '',
    historia: '',
    caracteristicas: '',
    image: 'https://i.imgur.com/placeholder.png'
  });

  const [chartType, setChartType] = useState('ventas');
  const [chartData, setChartData] = useState([]);

  useEffect(() => {
    fetchPhones();
    fetchHistory();
    fetchTransactions();
    fetchBalance();
  }, []);

  useEffect(() => {
    const fetchChartData = async () => {
      try {
        const endpoint =
          chartType === 'ventas'
            ? 'http://localhost:4000/stats/sales-by-model'
            : 'http://localhost:4000/stats/sales-by-month';

        const res = await axios.get(endpoint);
        if (chartType === 'ingresos') {
          const meses = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
          setChartData(
            res.data.map(item => ({
              ...item,
              month: meses[item._id - 1]
            }))
          );
        } else {
          setChartData(res.data);
        }
      } catch (err) {
        console.error('Error obteniendo datos de gráfica:', err);
      }
    };

    fetchChartData();
  }, [chartType]);

  const fetchPhones = async () => {
    try {
      const res = await axios.get('http://localhost:4000/phones');
      setPhones(res.data);
    } catch (err) {
      console.error('Error cargando celulares:', err);
    }
  };

  const fetchHistory = async () => {
    try {
      const res = await axios.get('http://localhost:4000/history');
      setHistory(res.data);
    } catch (err) {
      console.error('Error cargando historial:', err);
    }
  };

  const fetchTransactions = async () => {
    try {
      const res = await axios.get('http://localhost:4000/transactions');
      setTransactions(res.data);
    } catch (err) {
      console.error('Error cargando transacciones:', err);
    }
  };

  const fetchBalance = async () => {
    try {
      const res = await axios.get('http://localhost:4000/balance');
      setBalance(res.data);
    } catch (err) {
      console.error('Error cargando balance:', err);
    }
  };

  const handleTransactionChange = (e) => {
    const { name, value } = e.target;
    setTransactionForm({ ...transactionForm, [name]: value });
  };

  const handleTransactionSubmit = async () => {
    try {
      await axios.post('http://localhost:4000/transactions', {
        type: transactionForm.tipo,
        concepto: transactionForm.concepto,
        monto: parseFloat(transactionForm.monto),
        categoria: transactionForm.categoria
      });
      setTransactionForm({ tipo: 'ingreso', concepto: '', monto: '', categoria: '' });
      fetchTransactions();
      fetchBalance();
    } catch (err) {
      console.error('Error creando transacción:', err);
    }
  };

  const handleVentaSubmit = async () => {
    try {
      await axios.post(`http://localhost:4000/phones/sell/${ventaModal.phone._id}`, {
        monto: parseFloat(ventaModal.monto)
      });
      setVentaModal({ visible: false, phone: null, monto: '' });
      fetchPhones();
      fetchTransactions();
      fetchBalance();
    } catch (err) {
      console.error('Error al vender celular:', err);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData({ ...formData, image: reader.result });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRegister = async () => {
    if (!formData.model || !formData.price) return;
    try {
      await axios.post('http://localhost:4000/phones', {
        ...formData,
        price: parseInt(formData.price),
        stock: 1
      });
      setFormData({ model: '', price: '', historia: '', caracteristicas: '', image: 'https://i.imgur.com/placeholder.png' });
      fetchPhones();
      fetchHistory();
      setSelectedTab('stock');
    } catch (err) {
      console.error('Error registrando celular:', err);
    }
  };

  return (
    <div style={{ display: 'flex', height: '100vh', width: '100vw', overflow: 'hidden', fontFamily: 'sans-serif' }}>
      <div style={{ width: '240px', background: 'white', borderRight: '1px solid #ddd', padding: '24px' }}>
        <h2 style={{ color: '#7c3aed', marginBottom: '32px' }}>AstroCelulares</h2>
        <nav style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <button onClick={() => setSelectedTab('stock')}>📦 Stock</button>
          <button onClick={() => setSelectedTab('registro')}>➕ Registrar</button>
          <button onClick={() => setSelectedTab('grafica')}>📊 Gráficas</button>
          <button onClick={() => setSelectedTab('historial')}>📅 Historial</button>
          <button onClick={() => setSelectedTab('finanzas')}>💰 Finanzas</button>
        </nav>
      </div>

      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', backgroundColor: '#1f1f1f', color: 'white' }}>
        <div style={{ background: '#7c3aed', padding: '16px', display: 'flex', justifyContent: 'space-between' }}>
          <span>{selectedTab.toUpperCase()}</span>
          <div>👤 ⚙️</div>
        </div>

        <div style={{ padding: '24px', overflowY: 'auto', flex: 1 }}>
          {/* STOCK */}
          {selectedTab === 'stock' && (
            <div style={{ display: 'grid', gap: '16px', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))' }}>
              {phones.map((phone, idx) => (
                <div key={idx} style={{ backgroundColor: 'white', color: 'black', padding: '12px', borderRadius: '8px' }}>
                  <img src={phone.image} alt={phone.model} style={{ width: '100%', height: '140px', objectFit: 'cover' }} />
                  <strong>{phone.model}</strong>
                  <p>📦 {phone.stock} — 💰 ${phone.price}</p>
                  <button onClick={() => setVentaModal({ visible: true, phone, monto: '' })} style={{ marginTop: '8px', backgroundColor: '#7c3aed', color: 'white', padding: '4px 8px', borderRadius: '4px' }}>Vender</button>
                </div>
              ))}
            </div>
          )}

          {/* REGISTRO */}
          {selectedTab === 'registro' && (
            <div style={{ display: 'flex', gap: '32px' }}>
              <div style={{ flex: 1 }}>
                <div style={{ backgroundColor: 'white', borderRadius: '8px', padding: '12px', textAlign: 'center' }}>
                  <img src={formData.image} alt="preview" style={{ width: '100%', maxHeight: '300px', objectFit: 'contain' }} />
                  <input type="file" ref={fileInputRef} style={{ display: 'none' }} onChange={handleImageUpload} />
                  <button onClick={() => fileInputRef.current.click()} style={{ marginTop: '12px', backgroundColor: '#7c3aed', color: 'white', padding: '6px 12px', borderRadius: '4px' }}>Subir Imagen</button>
                </div>
              </div>
              <div style={{ flex: 1 }}>
                <h3>Registrar Celular</h3>
                <input name="model" placeholder="Modelo" value={formData.model} onChange={handleInputChange} style={{ display: 'block', marginBottom: '8px', width: '100%' }} />
                <input name="price" placeholder="Precio" value={formData.price} onChange={handleInputChange} style={{ display: 'block', marginBottom: '8px', width: '100%' }} />
                <input name="historia" placeholder="Historia" value={formData.historia} onChange={handleInputChange} style={{ display: 'block', marginBottom: '8px', width: '100%' }} />
                <input name="caracteristicas" placeholder="Características" value={formData.caracteristicas} onChange={handleInputChange} style={{ display: 'block', marginBottom: '8px', width: '100%' }} />
                <button onClick={handleRegister} style={{ backgroundColor: '#7c3aed', color: 'white', padding: '10px', width: '100%', borderRadius: '4px' }}>Registrar</button>
              </div>
            </div>
          )}

          {/* GRAFICA */}
          {selectedTab === 'grafica' && (
            <div>
              <h3>Gráficas</h3>
              <select onChange={(e) => setChartType(e.target.value)} value={chartType} style={{ marginBottom: '16px' }}>
                <option value="ventas">📈 Ventas por modelo</option>
                <option value="ingresos">💸 Ingresos mensuales</option>
              </select>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey={chartType === 'ventas' ? '_id' : 'month'} />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey={chartType === 'ventas' ? 'total' : 'revenue'} fill="#7c3aed" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}

          {/* HISTORIAL */}
          {selectedTab === 'historial' && (
            <div>
              <h3>Historial</h3>
              {history.map((item, idx) => (
                <div key={idx} style={{ backgroundColor: 'white', color: 'black', marginBottom: '8px', padding: '12px', borderRadius: '8px' }}>
                  <strong>{item.model}</strong>
                  <p>💰 ${item.price} | 📅 {new Date(item.dateAdded).toLocaleDateString()}</p>
                </div>
              ))}
            </div>
          )}

          {/* FINANZAS */}
          {selectedTab === 'finanzas' && (
            <div>
              <h3>Finanzas</h3>
              <p>💸 Ingresos: <strong style={{ color: 'lightgreen' }}>${balance.ingresos}</strong></p>
              <p>📤 Egresos: <strong style={{ color: 'tomato' }}>${balance.egresos}</strong></p>
              <p>📊 Utilidad: <strong style={{ color: 'gold' }}>${balance.utilidad}</strong></p>

              <h4>Registrar nueva transacción</h4>
              <select name="tipo" value={transactionForm.tipo} onChange={handleTransactionChange}>
                <option value="ingreso">Ingreso</option>
                <option value="egreso">Egreso</option>
              </select>
              <input name="concepto" placeholder="Concepto" value={transactionForm.concepto} onChange={handleTransactionChange} />
              <input name="monto" placeholder="Monto" value={transactionForm.monto} onChange={handleTransactionChange} />
              <input name="categoria" placeholder="Categoría" value={transactionForm.categoria} onChange={handleTransactionChange} />
              <button onClick={handleTransactionSubmit} style={{ marginTop: '8px', backgroundColor: '#7c3aed', color: 'white', padding: '8px 12px', borderRadius: '4px' }}>
                Registrar Transacción
              </button>

              <h4>Transacciones recientes</h4>
              <ul>
                {transactions.map((t, idx) => (
                  <li key={idx}>
                    <strong>{t.tipo.toUpperCase()}</strong> — {t.concepto} — ${t.monto} — {t.categoria}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
